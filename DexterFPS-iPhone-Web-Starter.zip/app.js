const fileInput=document.querySelector('#video');
const startBtn=document.querySelector('#start');
const fileInfo=document.querySelector('#fileInfo');
const panel=document.querySelector('#progressPanel');
const statusTitle=document.querySelector('#statusTitle');
const statusText=document.querySelector('#statusText');
const bar=document.querySelector('#bar');
const percent=document.querySelector('#percent');
const progressLabel=document.querySelector('#progressLabel');
const result=document.querySelector('#result');
let selectedFile=null;
fileInput.addEventListener('change',()=>{
  selectedFile=fileInput.files?.[0]||null;
  result.classList.add('hidden');
  if(!selectedFile){fileInfo.classList.add('hidden');startBtn.disabled=true;return;}
  const mb=(selectedFile.size/1024/1024).toFixed(1);
  fileInfo.textContent=`${selectedFile.name} · ${mb} MB`;
  fileInfo.classList.remove('hidden');
  startBtn.disabled=false;
});
startBtn.addEventListener('click',async()=>{
  if(!selectedFile)return;
  startBtn.disabled=true;panel.classList.remove('hidden');result.className='result hidden';
  setProgress(3,'جارٍ رفع الفيديو','يتم إرسال الملف إلى خادم المعالجة.');
  try{
    const form=new FormData();form.append('file',selectedFile);form.append('fps','120');
    const response=await fetch('/api/convert',{method:'POST',body:form});
    if(!response.ok){const body=await response.json().catch(()=>({detail:'تعذر بدء المعالجة'}));throw new Error(body.detail||'تعذر بدء المعالجة');}
    const data=await response.json();
    if(data.status==='completed'&&data.download_url){finish(data.download_url,data.filename||'DexterFPS-120fps.mp4');return;}
    if(!data.job_id)throw new Error('استجابة غير متوقعة من الخادم.');
    await pollJob(data.job_id);
  }catch(e){showError(e.message||'حدث خطأ. تأكد من اتصالك بالخادم وحاول مجددًا.');}
  finally{startBtn.disabled=false;}
});
async function pollJob(id){
  for(;;){
    await new Promise(r=>setTimeout(r,2500));
    const res=await fetch(`/api/jobs/${encodeURIComponent(id)}`);
    const data=await res.json().catch(()=>({}));
    if(!res.ok)throw new Error(data.detail||'تعذر متابعة المعالجة.');
    const p=Math.max(5,Math.min(99,Number(data.progress)||5));
    setProgress(p,data.status==='queued'?'في قائمة الانتظار':'جارٍ إنشاء الفريمات',data.message||'قد تستغرق المعالجة وقتًا حسب طول الفيديو.');
    if(data.status==='completed'){finish(data.download_url,data.filename||'DexterFPS-120fps.mp4');return;}
    if(data.status==='failed')throw new Error(data.error||'فشلت المعالجة.');
  }
}
function setProgress(p,title,subtitle){bar.style.width=p+'%';percent.textContent=Math.round(p)+'%';statusTitle.textContent=title;statusText.textContent=subtitle;progressLabel.textContent=p>=99?'اكتملت المعالجة':'قيد المعالجة';}
function finish(url,name){setProgress(100,'المقطع جاهز','تمت معالجة الفيديو.');result.className='result';result.textContent=`اكتمل التحويل إلى 120 FPS. اسم الملف: ${name}`;const a=document.createElement('a');a.href=url;a.download=name;a.textContent='تنزيل الفيديو الناتج';result.appendChild(a);}
function showError(msg){result.className='result error';result.textContent=msg;statusTitle.textContent='تعذر إكمال التحويل';statusText.textContent='تحقق من إعداد الخادم ثم أعد المحاولة.';}
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));}
