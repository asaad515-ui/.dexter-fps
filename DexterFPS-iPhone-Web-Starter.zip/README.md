# Dexter FPS — iPhone-first cloud frame interpolation PWA

A starter web app that can be opened in iPhone Safari and added to the Home Screen. It uploads a video to a server and uses FFmpeg `minterpolate` (motion estimation/compensation) to synthesize intermediate frames and export 120 fps MP4.

## Important reality check
- This is a working **starter implementation**, not a hosted public service. You must deploy it to a server before Safari uploads can work.
- `minterpolate` is genuine optical-flow/motion-compensated interpolation, but it is not a learned AI model. Fast motion, camera cuts, occlusions and footballs can cause warping/ghosting.
- Output is encoded at 120 fps. That does not guarantee every source gains detail, nor does it mean the iPhone display plays 120 fps.
- Server currently stores jobs in memory and temporary local disk. Do not use as-is for a public production service. Production needs durable queue/storage, authentication, upload quotas, cleanup, TLS, monitoring, privacy policy and cost controls.
- Hosting providers may impose CPU, memory, execution-time and disk limits. Video interpolation is CPU intensive. Test on short clips first.
- Uploaded videos are processed on the server. Do not upload private/sensitive content.

## Run locally (developer computer)
Requires Docker:
```bash
docker build -t dexter-fps .
docker run --rm -p 8080:8080 -e PORT=8080 dexter-fps
```
Open `http://localhost:8080`. For iPhone testing, deploy the container to a service that supports Docker and HTTPS, then open its HTTPS URL in Safari.

## Deploy (high-level)
1. Create a Docker-compatible web service with persistent or sufficient temporary storage and enough CPU/RAM.
2. Deploy this repository using the included `Dockerfile`; set the service port to `8080` (or allow the platform to set `PORT`).
3. Ensure HTTPS is enabled. Check `/api/health` and confirm `ffmpeg_available: true`.
4. Open the HTTPS address in iPhone Safari. Use Share → Add to Home Screen.
5. Test with a short, non-sensitive clip before trying longer footage. Check service limits and costs.

## iPhone install
In Safari, open the deployed HTTPS URL → Share → **Add to Home Screen** → Add. This is a web app/PWA, not a signed native App Store app.

## API
- `GET /api/health`
- `POST /api/convert` multipart fields: `file`, `fps=120`
- `GET /api/jobs/{job_id}`
- `GET /api/download/{job_id}`

## Engineering notes
- Conversion filter: `minterpolate=fps=120:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1`
- Output: H.264 MP4, AAC audio, `yuv420p`, 120 fps, fast-start.
- The starter limits upload size to 500 MB by default (`MAX_UPLOAD_MB`) and conversion timeout to one hour (`CONVERT_TIMEOUT_SECONDS`).
- In-memory jobs disappear on restart and output files are not automatically cleaned. Add a proper queue and TTL cleanup before public use.
