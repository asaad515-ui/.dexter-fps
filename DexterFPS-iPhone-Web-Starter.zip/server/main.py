import os, uuid, shutil, subprocess, threading
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent.parent
DATA = Path(os.getenv("DEXTER_DATA_DIR", "/tmp/dexter-fps"))
INBOX = DATA / "inbox"
OUTBOX = DATA / "outbox"
for p in (INBOX, OUTBOX): p.mkdir(parents=True, exist_ok=True)
app = FastAPI(title="Dexter FPS API")
jobs = {}
lock = threading.Lock()
MAX_BYTES = int(os.getenv("MAX_UPLOAD_MB", "500")) * 1024 * 1024
ALLOWED = {".mp4", ".mov", ".m4v", ".webm"}

def run_conversion(job_id, source, output):
    try:
        with lock: jobs[job_id].update(status="processing", progress=5, message="Preparing video")
        # FFmpeg minterpolate uses motion estimation and compensation to synthesize
        # intermediate frames. It is real interpolation, not metadata-only FPS change.
        cmd = [
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
            "-map", "0:v:0", "-map", "0:a?", "-vf",
            "minterpolate=fps=120:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1",
            "-c:v", "libx264", "-preset", os.getenv("FFMPEG_PRESET", "veryfast"),
            "-crf", "18", "-pix_fmt", "yuv420p", "-r", "120",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(output)
        ]
        # subprocess.run is simple and robust for the starter. A production deployment
        # should use a persistent queue, progress parsing, rate limits and cleanup.
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=int(os.getenv("CONVERT_TIMEOUT_SECONDS","3600")))
        if result.returncode != 0:
            raise RuntimeError((result.stderr or "FFmpeg conversion failed")[-1600:])
        with lock:
            jobs[job_id].update(status="completed", progress=100, message="Done",
                                download_url=f"/api/download/{job_id}",
                                filename=output.name)
    except Exception as exc:
        with lock: jobs[job_id].update(status="failed", progress=0, error=str(exc)[:1800])
    finally:
        try: source.unlink(missing_ok=True)
        except Exception: pass

@app.get("/api/health")
def health():
    ffmpeg = shutil.which("ffmpeg")
    return {"ok": bool(ffmpeg), "ffmpeg_available": bool(ffmpeg)}

@app.post("/api/convert")
async def convert(file: UploadFile = File(...), fps: str = Form("120")):
    if fps != "120":
        raise HTTPException(400, "Dexter FPS currently supports 120 FPS output only.")
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(415, "Use an MP4, MOV, M4V or WEBM video.")
    job_id = uuid.uuid4().hex
    source = INBOX / f"{job_id}{ext}"
    output = OUTBOX / f"DexterFPS-120fps-{job_id[:8]}.mp4"
    size = 0
    try:
        with source.open("wb") as dest:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_BYTES:
                    raise HTTPException(413, f"File exceeds the {MAX_BYTES // (1024*1024)} MB upload limit.")
                dest.write(chunk)
    except Exception:
        source.unlink(missing_ok=True)
        raise
    finally:
        await file.close()
    with lock: jobs[job_id] = {"status":"queued","progress":2,"message":"Queued"}
    threading.Thread(target=run_conversion, args=(job_id, source, output), daemon=True).start()
    return {"job_id": job_id, "status":"queued"}

@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    with lock: data = jobs.get(job_id)
    if not data: raise HTTPException(404, "Job not found. Jobs reset when the server restarts.")
    return data

@app.get("/api/download/{job_id}")
def download(job_id: str):
    with lock: data = jobs.get(job_id)
    if not data or data.get("status") != "completed": raise HTTPException(404, "Output not ready.")
    path = OUTBOX / data["filename"]
    if not path.exists(): raise HTTPException(404, "Output file expired or unavailable.")
    return FileResponse(path, media_type="video/mp4", filename=data["filename"])

# Serve the PWA from the same origin as the API.
app.mount("/", StaticFiles(directory=str(BASE), html=True), name="web")
